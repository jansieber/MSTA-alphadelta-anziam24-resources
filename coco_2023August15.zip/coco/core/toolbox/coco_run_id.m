function [runid] = coco_run_id(opts)
runid = opts.run.runid;
end
