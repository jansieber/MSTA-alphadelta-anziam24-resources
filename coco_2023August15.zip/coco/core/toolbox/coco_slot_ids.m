function list = coco_slot_ids(results) % no longer in use?

list = results(:,1);
