% Continuation Core Toolbox
% Copyright (C) Frank Schilder, Harry Dankowicz
%
%   coco                   - Execute a continuation run.
%   coco_add_chart_data    - Add chart data to problem.
%   coco_add_event         - Add event to parameter.
%   coco_add_func          - Add function to system of equations.
