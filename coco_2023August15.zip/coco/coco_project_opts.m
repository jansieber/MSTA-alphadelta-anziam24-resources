function prob = coco_project_opts(prob)
prob = coco_project_opts_recipes(prob);
end
