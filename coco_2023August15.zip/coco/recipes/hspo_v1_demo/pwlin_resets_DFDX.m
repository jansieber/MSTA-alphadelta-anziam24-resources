function J = pwlin_resets_DFDX(x, p, reset)
%PWLIN_RESETS_DFDX   'hspo'-compatible encoding of Jacobian of event function with respect to problem variables.
  J = eye(2);
end
