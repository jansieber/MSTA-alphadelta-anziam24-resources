function [data y] = plan(prob, data, u)
%PLAN   COCO-compatible encoding of plane function.
  y = u(1)+u(2);
end
